// This file is compiled to devtools-snippet.js and injected at the beginning
// of user scripts when enableDevtools is true. It overrides console methods to
// forward logs to the Acurast DevTools API.
//
// Placeholder https://api.devtools.acurast.com is replaced at injection time.
;
(() => {
    const DEVTOOLS_API_URL = 'https://api.devtools.acurast.com';
    const originalConsole = {
        log: console.log,
        warn: console.warn,
        error: console.error,
        info: console.info,
        debug: console.debug,
    };
    // --- Auth: obtain a Bearer token from the devtools API ---
    let apiKey = null;
    const pendingLogs = []; // buffered payloads while awaiting auth
    const toHex = (str) => {
        let hex = '';
        for (let i = 0; i < str.length; i++) {
            hex += str.charCodeAt(i).toString(16).padStart(2, '0');
        }
        return hex;
    };
    const sendBuffered = () => {
        for (const body of pendingLogs.splice(0)) {
            httpPOST(`${DEVTOOLS_API_URL}/v1/logs`, body, { 'Content-Type': 'application/json', Authorization: 'Bearer ' + apiKey }, () => { }, (error) => {
                originalConsole.error('[devtools] buffered log post failed:', error);
            });
        }
    };
    try {
        // The full "origin:owner:number" deployment id. The API needs the owner to
        // find the job on chain: job storage is keyed by (origin, number) under a
        // one-way hasher, so a bare number cannot be resolved there.
        const rawId = _STD_.job.getId();
        const jobNumber = String(rawId.id);
        const origin = rawId.origin;
        const jobId = origin && origin.kind && origin.source
            ? origin.kind + ':' + origin.source + ':' + jobNumber
            : jobNumber;
        const processorAddress = _STD_.device.getAddress();
        const pubKeyHex = _STD_.job.getPublicKeys().ed25519;
        const timestamp = String(Math.floor(Date.now() / 1000));
        // Bound to the deployment so a captured signature cannot be reused against
        // another job.
        const message = pubKeyHex + ':' + jobId + ':' + timestamp;
        const messageHex = toHex(message);
        const signatureHex = _STD_.signers.ed25519.sign(messageHex);
        httpPOST(`${DEVTOOLS_API_URL}/v1/auth/api-key`, JSON.stringify({ jobId, processorAddress }), {
            'Content-Type': 'application/json',
            'X-Signature': signatureHex,
            'X-PublicKey': pubKeyHex,
            'X-Timestamp': timestamp,
        }, (response, _certificate) => {
            try {
                const parsed = JSON.parse(response);
                apiKey = parsed.apiKey;
                sendBuffered();
            }
            catch (_e) {
                originalConsole.error('[devtools] failed to parse auth response:', response);
            }
        }, (error) => {
            originalConsole.error('[devtools] auth failed:', error);
        });
    }
    catch (e) {
        originalConsole.error('[devtools] auth setup failed:', e?.message ?? String(e));
    }
    // --- Rate limiting ---
    const RATE_LIMIT_MAX = 20;
    const RATE_LIMIT_WINDOW_MS = 10000;
    let rateBucketStart = Date.now();
    let rateBucketCount = 0;
    let dropped = 0;
    const sendLog = (level, args) => {
        const now = Date.now();
        if (now - rateBucketStart >= RATE_LIMIT_WINDOW_MS) {
            if (dropped > 0) {
                enqueue([
                    {
                        type: 'warn',
                        data: `[devtools] rate limit ended: ${dropped} log(s) were dropped`,
                        timestamp: now,
                    },
                ]);
            }
            rateBucketStart = now;
            rateBucketCount = 0;
            dropped = 0;
        }
        if (rateBucketCount >= RATE_LIMIT_MAX) {
            dropped++;
            return;
        }
        rateBucketCount++;
        try {
            const data = args.length === 1 ? args[0] : args;
            let serializable;
            try {
                JSON.stringify(data);
                serializable = data;
            }
            catch {
                serializable = String(data);
            }
            enqueue([{ type: level, data: serializable, timestamp: now }]);
        }
        catch (_e) {
            // Silently ignore serialization errors to avoid breaking user scripts
        }
    };
    const enqueue = (entries) => {
        const body = JSON.stringify(entries);
        if (apiKey) {
            httpPOST(`${DEVTOOLS_API_URL}/v1/logs`, body, { 'Content-Type': 'application/json', Authorization: 'Bearer ' + apiKey }, () => { }, (error) => {
                originalConsole.error('[devtools] log post failed:', error);
            });
        }
        else {
            pendingLogs.push(body);
        }
    };
    // --- File upload via /v1/files ---
    const uploadFile = (filename, content, mimeType, onSuccess, onError) => {
        if (!apiKey) {
            onError('[devtools] file upload failed: not authenticated yet');
            return;
        }
        // The processor's httpPOST JSON-parses the body regardless of Content-Type,
        // so we cannot send multipart/form-data through it. Use fetch + FormData
        // instead — fetch sets the Content-Type header (with boundary) automatically.
        const formData = new FormData();
        formData.append('file', new Blob([content], { type: mimeType }), filename);
        fetch(`${DEVTOOLS_API_URL}/v1/files`, {
            method: 'POST',
            headers: { Authorization: 'Bearer ' + apiKey },
            body: formData,
        })
            .then((res) => res.text().then((text) => ({ ok: res.ok, status: res.status, text })))
            .then(({ ok, status, text }) => {
            if (!ok) {
                onError('[devtools] file upload failed: HTTP ' + status + ' ' + text);
                return;
            }
            try {
                onSuccess(JSON.parse(text));
            }
            catch (_e) {
                onError('[devtools] failed to parse upload response: ' + text);
            }
        })
            .catch((err) => {
            onError('[devtools] file upload failed: ' + (err?.message ?? String(err)));
        });
    };
    globalThis._DEVTOOLS_ = { uploadFile };
    for (const level of Object.keys(originalConsole)) {
        ;
        console[level] = (...args) => {
            originalConsole[level](...args);
            sendLog(level, args);
        };
    }
})();
/**
 * Acurast Monitor-as-a-Service  (Engine 4 — Product A)
 * Runs ON the processor. Polls customer URLs and POSTs a failure alert to a
 * webhook. Uses the documented processor runtime API only
 * (print, httpGET, httpPOST, _STD_.env).
 */
function monitorOne(url) {
  print("checking " + url);
  httpGET(
    url,
    { "Accept": "application/json, text/plain, */*" },
    function (payload, cert) {
      print("OK " + url + " (len=" + payload.length + ")");
    },
    function (errMsg) {
      var body = JSON.stringify({
        url: url,
        status: "DOWN",
        error: errMsg,
        ts: Date.now(),
        processor: _STD_.device.getAddress(),
      });
      print("ALERT " + url + " -> " + errMsg);
      var hook = _STD_.env["ALERT_WEBHOOK"];
      if (hook) {
        httpPOST(
          hook,
          body,
          { "Content-Type": "application/json" },
          function () { print("alert delivered " + url); },
          function (e) { print("alert post failed " + e); }
        );
      }
    }
  );
}

function main() {
  var targets = (_STD_.env["TARGET_URL"] || "").split(",").map(function (s) { return s.trim(); }).filter(Boolean);
  if (!targets.length) {
    print("no TARGET_URL configured");
    return;
  }
  targets.forEach(monitorOne);
}

main();
